<?php include('messages.php');?>
<form method="POST" name="zapisz" action="/login">
    <h3 class="h3 mb-3 fw-normal">Login</h3>
    <div class="form-floating">
        <input type="text" name="username" value="username1" class="form-control" id="floatingInput" placeholder="">
        <label for="floatingInput">Email address</label>
    </div>
    <div class="form-floating">
        <input type="password" name="password" value="lubiemaslo" class="form-control" id="floatingPassword" placeholder="Password">
        <label for="floatingPassword">Password</label>
    </div>
    <button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
    <input type="hidden" name="form_name" value="form_login">
</form>

