<div class="col">
    <?php if(isset($forms)&&array_key_exists('form_user_create',$forms)):?>
        <?=$forms['form_user_create'];?>
    <?php endif;?>
</div>
<div class="col">
    <?php if(isset($forms)&&array_key_exists('form_login',$forms)):?>
        <?=$forms['form_login'];?>
    <?php endif;?>
</div>