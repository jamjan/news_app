<form method="POST" name="new_user" action="/user/create">
    <h3 class="h3 mb-3 fw-normal">Register</h3>
    <div class="form-floating">
        <input type="text" name="name" value="" class="form-control" id="floatingInput" placeholder="Username">
        <label for="floatingInput">Username</label>
    </div>
    <div class="form-floating">
        <input type="password" name="password[original]" value="" class="form-control" id="floatingPassword" placeholder="Password">
        <label for="floatingPassword">Password</label>
    </div>
    <div class="form-floating">
        <input type="password" name="password[confirm]" value="" class="form-control" id="floatingPasswordConfirm" placeholder="Repeat password">
        <label for="floatingPasswordConfirm">Repeat Password</label>
    </div>
    <button class="w-100 btn btn-lg btn-primary" type="submit">Create Account</button>
    <input type="hidden" name="form_name" value="form_user_create">
</form>