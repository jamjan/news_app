<?php
declare(strict_types=1);

use App\Application\Middleware\SessionMiddleware;
use App\Common\Middleware\HostnameMiddleware;
use App\Authentication\Middleware\AuthenticationServiceMiddleware;
use Slim\App;

return function (App $app) {
    $app->add(SessionMiddleware::class);
    $app->add(HostnameMiddleware::class);
//    $app->add(AuthenticationServiceMiddleware::class);
};
