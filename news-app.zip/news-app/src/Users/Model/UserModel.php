<?php

namespace App\Users\Model;

use App\Common\Domain\CommonModel;

class UserModel extends CommonModel
{
    protected $table_name = "users";

    public function checkIfUserExistsByUsername($username)
    {
        return $this->read(['username'=>$username]);
    }
}