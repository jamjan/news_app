<?php
declare(strict_types=1);

namespace App\Users\Actions;

use App\Application\Actions\Action;
use App\Authentication\Service\AuthService;
use App\News\Domain\NewsModel;
use App\News\Domain\TagsModel;
use App\Users\Model\UserModel;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Log\LoggerInterface;
use Slim\Views\PhpRenderer;

class CreateUsersAction extends Action
{
    protected UserModel $userModel;
    protected PhpRenderer $phpRenderer;
    protected AuthService $authService;

    const FORMNAME_CREATE = "form_users_create";

    public function __construct(LoggerInterface $logger, UserModel $userModel, PhpRenderer $phpRenderer, AuthService $authService)
    {
        parent::__construct($logger);
        $this->phpRenderer = $phpRenderer;
        $this->authService = $authService;
        $this->userModel = $userModel;
    }

    protected function action(): Response
    {
        $isLoggedIn = $this->request->getAttribute(AuthService::ATTR_ISLOGGEDIN);
        $isAdminUser = $this->request->getAttribute(AuthService::ATTR_ISADMIN);

        if($isAdminUser OR $isLoggedIn) {
            $this->authService->forbidden();
        }


        $postBody = $this->request->getParsedBody();

        if(isset($postBody['form_name'])&&$postBody['form_name']===self::FORMNAME_CREATE) {
            $postData = [
                'title'=>htmlspecialchars(trim($postBody['title'])),
                'description'=>htmlspecialchars(trim($postBody['description'])),
                'content'=>htmlspecialchars(trim($postBody['content'])),
                'date_created'=>date('Y-m-d H:i:s'),
            ];

            $this->userModel->create($postData);
        }


        return $this->phpRenderer->render($this->response, "form-user-create.php");

    }
}
