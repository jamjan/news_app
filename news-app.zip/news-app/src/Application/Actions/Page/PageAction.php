<?php
declare(strict_types=1);

namespace App\Application\Actions\Page;

use App\Application\Actions\Action;
use App\Domain\User\UserRepository;
use App\News\Domain\NewsModel;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Log\LoggerInterface;
use Slim\Views\PhpRenderer;
use App\Authentication\Service\AuthService;

class PageAction extends Action
{
    protected AuthService $authService;

    protected NewsModel $newsModel;

    protected PhpRenderer $phpRenderer;

    public function __construct(LoggerInterface $logger, NewsModel $newsModel,PhpRenderer $phpRenderer,AuthService $authService)
    {
        parent::__construct($logger);

        $this->authService = $authService;
        $this->newsModel = $newsModel;
        $this->phpRenderer = $phpRenderer;

    }

    protected function action(): Response
    {
        $news = $this->newsModel->readAll();

        return $this->phpRenderer->render($this->response, "homepage.php", ['news'=>$news]);

    }
}
