<?php
declare(strict_types=1);

namespace App\Authentication\Actions;


use App\Application\Actions\Action;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Log\LoggerInterface;
use Slim\Views\PhpRenderer;
use App\Authentication\Service\AuthService;

class AuthenticateAction extends Action
{
    protected AuthService $authService;

    protected PhpRenderer $phpRenderer;

    public function __construct(LoggerInterface $logger, AuthService $authService, PhpRenderer $phpRenderer)
    {
        parent::__construct($logger);
        $this->authService = $authService;
        $this->phpRenderer = $phpRenderer;
    }




    /**
     * {@inheritdoc}
     */
    protected function action(): Response
    {

        $is_logged_in = $this->authService->isLoggedIn();

        $requestMethod = $this->request->getMethod();
        if( ! $is_logged_in
            && strtolower($requestMethod)==="post"
        ) {
            $postBody = $this->request->getParsedBody();
            if(!empty($postBody)
                && is_array($_POST)
                && ! empty($_POST['username'])
                && ! empty($_POST['password'])
                && strlen($_POST['password']) > 3
                && array_key_exists('form_name',$_POST)
                && $_POST['form_name']==='form_login')
            {
                // user submitted login form
                $username = htmlspecialchars(trim($postBody['username']));
                $password = htmlspecialchars(trim($postBody['password']));

                $isAuthValid = $this->authService->authenticate($username,$password);

                if($isAuthValid) {
                    $this->authService->login($isAuthValid['id'],$isAuthValid['username'],);
//                    $this->utilities->addMessage("Zalogowano pomyslnie.");


                    return $this->phpRenderer->render($this->response, "homepage.php",['forms'=>[],'is_logged_in'=>$is_logged_in]);
                }
            }

            $forms['form_login'] = $this->phpRenderer->fetch("form-login.php");

            return $this->phpRenderer->render($this->response, "homepage.php",['forms'=>$forms,'is_logged_in'=>$is_logged_in]);

        } else {
            $forms['form_login'] = $this->phpRenderer->fetch("form-login.php");

            return $this->phpRenderer->render($this->response, "homepage.php",['forms'=>$forms,'is_logged_in'=>$is_logged_in]);
        }
    }
}
