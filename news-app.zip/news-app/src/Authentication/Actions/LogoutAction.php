<?php
declare(strict_types=1);

namespace App\Authentication\Actions;


use App\Application\Actions\Action;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Log\LoggerInterface;
use Slim\Views\PhpRenderer;
use App\Authentication\Service\AuthService;

class LogoutAction extends Action
{
    protected AuthService $authService;

    protected PhpRenderer $phpRenderer;

    public function __construct(LoggerInterface $logger, AuthService $authService, PhpRenderer $phpRenderer)
    {
        parent::__construct($logger);
        $this->authService = $authService;
        $this->phpRenderer = $phpRenderer;
    }




    /**
     * {@inheritdoc}
     */
    protected function action(): Response
    {
        $this->authService->logout();

        $is_logged_in = $this->authService->isLoggedIn();
        $forms['form_login'] = $this->phpRenderer->fetch("form-login.php");

        return $this->phpRenderer->render($this->response, "homepage.php",['forms'=>$forms,'is_logged_in'=>$is_logged_in]);
    }
}
