<?php
declare(strict_types=1);

namespace App\Application\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface as Middleware;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use App\Authentication\Service\AuthService;

class AuthenticationServiceMiddleware implements Middleware
{
    /**
     * {@inheritdoc}
     */
    public function process(Request $request, RequestHandler $handler): Response
    {

//        var_dump(AuthService::ATTR_ISLOGGEDIN);die();
//        $request = $request->withAttribute(, $this->authService->isLoggedIn());

//        $authService = $this->get(AuthService::class);
//        $request = $request->withAttribute(AuthService, null);

        return $handler->handle($request);
    }
}
