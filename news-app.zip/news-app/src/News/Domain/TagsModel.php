<?php
declare(strict_types=1);

namespace App\News\Domain;

use App\Common\Domain\CommonModel;

class TagsModel extends CommonModel
{
    protected $table_name = "tags";

}
