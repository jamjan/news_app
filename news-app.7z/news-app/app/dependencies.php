<?php
declare(strict_types=1);

use App\Application\Settings\SettingsInterface;
use DI\ContainerBuilder;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Monolog\Processor\UidProcessor;
use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use Slim\Views\PhpRenderer;
use App\Authentication\Service\AuthService;
use App\Users\Model\UserModel;

return function (ContainerBuilder $containerBuilder) {
    $containerBuilder->addDefinitions([
        LoggerInterface::class => function (ContainerInterface $c) {
            $settings = $c->get(SettingsInterface::class);

            $loggerSettings = $settings->get('logger');
            $logger = new Logger($loggerSettings['name']);

            $processor = new UidProcessor();
            $logger->pushProcessor($processor);

            $handler = new StreamHandler($loggerSettings['path'], $loggerSettings['level']);
            $logger->pushHandler($handler);

            return $logger;
        },
        PhpRenderer::class => function (ContainerInterface $c) {
            $phpRenderer = new PhpRenderer();
            $phpRenderer->setTemplatePath(__DIR__ . '/../templates');
            $phpRenderer->setLayout('layout.php');

            return $phpRenderer;
        },
        AuthService::class =>  \DI\autowire(AuthService::class),
    ]);
};
