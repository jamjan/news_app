<?php
declare(strict_types=1);

use App\Application\Actions\Page\HomepageAction;
use App\Application\Actions\User\ListUsersAction;
use App\Application\Actions\User\ViewUserAction;
use App\Authentication\Actions\AuthenticateAction;
use App\Authentication\Actions\LogoutAction;
use App\News\Actions\CreateNewsAction;
use App\News\Actions\ReadAllNewsAction;
use App\News\Domain\FilterModel;
use App\News\Domain\TagsModel;
use App\Users\Actions\CreateUsersAction;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\App;
use Slim\Interfaces\RouteCollectorProxyInterface as Group;
use Slim\Views\PhpRenderer;

return function (App $app) {
    $app->options('/{routes:.*}', function (Request $request, Response $response) {
        // CORS Pre-Flight OPTIONS Request Handler
        return $response;
    });

    $app->get('/', HomepageAction::class);

    $app->get('/news', ReadAllNewsAction::class);

    $app->get('/news/create', CreateNewsAction::class);
    $app->post('/news/create', CreateNewsAction::class);

    $app->get('/register', CreateUsersAction::class);


    $app->post('/filter', function (Request $request, Response $response) {

        $filterModel = new FilterModel();

        $tagsModel = new TagsModel();
        $filterPostData = $request->getParsedBody();

        $tagsList = $tagsModel->readAll();


        if(!empty($filterPostData['tags'])&&$filterPostData['tags']==='0'){
            $filterPostData['tags'] = null;
        }

        $result = $filterModel->filterByDateAndTags($filterPostData['date']['start'],$filterPostData['date']['end'],$filterPostData['tags']);

        $renderer = new PhpRenderer(__DIR__ . '/../templates');
        $renderer->setLayout('layout.php');

        return $renderer->render($response, "news-list.php", ['news_list'=>$result,'tags_list'=>$tagsList,'selected_tag'=>$filterPostData['tags']]);
    });

    $app->get('/login', AuthenticateAction::class);
    $app->post('/login', AuthenticateAction::class);
    $app->get('/logout', LogoutAction::class);

    $app->group('/users', function (Group $group) {
        $group->get('', ListUsersAction::class);
        $group->get('/{id}', ViewUserAction::class);
    });
};
