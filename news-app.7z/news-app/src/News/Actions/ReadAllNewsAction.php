<?php
declare(strict_types=1);

namespace App\News\Actions;

use App\Application\Actions\Action;
use App\Domain\User\UserRepository;
use App\News\Domain\NewsModel;
use App\News\Domain\TagsModel;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Log\LoggerInterface;
use Slim\Views\PhpRenderer;
use App\Authentication\Service\AuthService;

class ReadAllNewsAction extends Action
{
    protected NewsModel $newsModel;

    protected TagsModel $tagsModel;
    protected AuthService $authService;

    protected PhpRenderer $phpRenderer;

    public function __construct(
        LoggerInterface $logger,
        NewsModel $newsModel,
        PhpRenderer $phpRenderer,
        TagsModel $tagsModel,
        AuthService $authService
    )
    {
        parent::__construct($logger);

        $this->newsModel = $newsModel;
        $this->phpRenderer = $phpRenderer;
        $this->tagsModel = $tagsModel;
        $this->authService = $authService;
    }

    protected function action(): Response
    {

        $isLoggedIn = $this->request->getAttribute(AuthService::ATTR_ISLOGGEDIN);

        if(!$isLoggedIn) {
            $_SESSION['message'][] = "Must be logged in;";

            $this->authService->forbidden();

        }

        $newsList = $this->newsModel->readAll();
        $tagsList = $this->tagsModel->readAll();


        return $this->phpRenderer->render($this->response, "news-list.php", ['news_list'=>$newsList,'tags_list'=>$tagsList,'is_logged_in'=>$isLoggedIn]);

    }
}
