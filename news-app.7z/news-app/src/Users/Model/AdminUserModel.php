<?php

namespace App\Users\Model;

use App\Common\Domain\CommonModel;

class AdminUserModel extends CommonModel
{
    protected $table_name = "user_admin";
}