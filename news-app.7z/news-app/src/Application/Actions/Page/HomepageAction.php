<?php
declare(strict_types=1);

namespace App\Application\Actions\Page;

use App\Application\Actions\Action;
use App\Domain\User\UserRepository;
use App\News\Domain\NewsModel;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Log\LoggerInterface;
use App\Authentication\Service\AuthService;
use Slim\Views\PhpRenderer;

class HomepageAction extends PageAction
{
    protected NewsModel $newsModel;

    protected PhpRenderer $phpRenderer;

    protected function action(): Response
    {
        $is_logged_in = $this->request->getAttribute(AuthService::ATTR_ISLOGGEDIN);

        $forms['form_login'] = ($is_logged_in)?$is_logged_in:$this->phpRenderer->fetch("form-login.php");
        $forms['form_user_create'] = ($is_logged_in)?$is_logged_in:$this->phpRenderer->fetch("form-user-create.php");

        return $this->phpRenderer->render($this->response, "homepage.php",['forms'=>$forms,'is_logged_in'=>$is_logged_in]);

    }
}
