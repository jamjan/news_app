<form action="/filter" method="POST">
    <label for="tags">Tags</label>
    <select id="tags" name="tags">
        <option value="0">All</option>
        <?php foreach($tags_list as $tagIndex=>$tagData):?>
        <option value="<?=$tagData['id'];?>" <?php if(isset($selected_tag)&& intval($selected_tag)==intval($tagData['id'])){ echo " selected='selected'";}?>><?=$tagData['title'];?></option>
        <?php endforeach;?>
    </select>
    <label for="dateStart">Date From</label>
    <input id="dateStart" type="date" name="date[start]"/>
    <label for="dateEnd">Date To</label>
    <input id="dateEnd" type="date" name="date[end]" />
    <input type="hidden" name="form_name" value="news_filter" />
    <input type="submit" value="Filter" />
</form>
 <hr class="my-5" />


<?php
foreach($news_list as $index=>$newsItem):
?>
    <div class="col-12">
        <h2><?=$newsItem['title'];?></h2>
        <p class="small"><?=$newsItem['description'];?></p>
        <p><?=$newsItem['content'];?></p>
    </div>


<?php endforeach;?>